'use strict';

import React, { Component } from 'react';
import '../style/about.scss';

export default class About extends Component {
    render() {
        return (
            <div className="about">
                <div>Cистема обліку товарно матеріальних цінностей (ТМЦ)</div>
            </div>
        )
    }
}